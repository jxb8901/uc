package com.opensymphony.module.sitemesh.html;

public interface StateChangeListener {
	void stateFinished();
}
